
var cities = ["kwt","Ddubai","Bagdad"]
print(cities[1])
var countries = ["KSA","UAE","KWT"]
print(countries)
countries.append("algea")
print("array after append \(countries)")
countries += ["yamn","oman"]
print("array after new append \(countries)")
countries.insert("iraq", at: 1)
print("array after insert \(countries)")
countries[2] = "morocco"
print("array after replay\(countries)")
countries.remove(at: 4)
print("array after remove\(countries)")
print(countries[5])
