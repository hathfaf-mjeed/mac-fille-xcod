// variables
var FrastName = "ail"
FrastName = "balz"

var MiddleName = "hudifa"
MiddleName = "AZIZ"

var LastName = "majeed"
LastName = "klife"

var x = 5
x = Int(5.5)

var y : Float = 5.9
y = 2

var z : Double = 2.743747

print(FrastName + " " + MiddleName + " " + LastName ); print(z)

var hascar = true
hascar = false



// Constants
let tax = 00.5

let age : Float = 20

let hasphone : Bool
hasphone = true

print(hasphone)



// summary
var name = "fahd" , carName = "BMW"

var pric : Int = 10
pric = 12

let cityName = "kwt"

print(pric)

print(name + " " + carName + " " + cityName)
